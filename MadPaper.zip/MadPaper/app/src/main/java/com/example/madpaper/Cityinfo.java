package com.example.madpaper;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Cityinfo extends AppCompatActivity {

    TextView textview1,textView2,textView3;
    ImageView imageView;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cityinfo);

        textview1= findViewById(R.id.text1);
        textView2 = findViewById(R.id.text2);
        textView3 = findViewById(R.id.text3);
        imageView = findViewById(R.id.imageview1);
        btn = findViewById(R.id.button);

        Intent intent=getIntent();

        imageView.setImageResource(intent.getIntExtra("image" , 0));
        textview1.setText(intent.getStringExtra("cityname"));
        textView2.setText(intent.getStringExtra("citydescription"));
        textView3.setText(intent.getStringExtra("cityprice"));
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Cityinfo.this, "Successfuly booked", Toast.LENGTH_LONG).show();
            }
        });
    }
}