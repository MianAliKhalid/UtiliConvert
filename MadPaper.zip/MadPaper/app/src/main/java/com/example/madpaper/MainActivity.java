package com.example.madpaper;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    String cityname[] = {"Lahore","Murree","Kaghan","Kashmir","Karachi","Multan"};
    int image[] = {R.drawable.lahore,R.drawable.murree,R.drawable.kaghan,R.drawable.jammukashmir,R.drawable.karachi,R.drawable.multan};
    String price[] = {"20000-25000","30000-35000","40000-45000","50000-55000","60000-65000","70000-75000"};
    String descriptions[] = {"Lahore is a wonderfull city with lot of populations rate and it has many locations to visit." +
            "Since it has strong historical background so there are many historical place to visit in Lahore",
    "Murree is a Located on the mountain and the weather and view is very enjoyable.It forms the outskirts of the Islamabad-" +
            "Rawalpindi metropolitan area, and is about 30 km (19 mi) northeast of Islamabad. It has average altitude of 2,291 " +
            "metres (7,516 ft). The British built this town during their rule to escape the scorching heat in the plains of Punjab during the summer",
    "The Kaghan Valley is an alpine valley located in the Hazara region in the Mansehra District of Khyber Pakhtunkhwa, Pakistan. The valley covers a distance of 155 kilometres (96 mi) across northern Pakistan, rising from its lowest elevation of 650 m (2,134 ft) to its highest point at the Babusar Pass around 4,170 m (13,690 ft).Landslides triggered by the devastating 2005 Kashmir earthquake destroyed many passes leading into the valley, though roads have since been largely rebuilt. The Kaghan is a highly popular tourist attraction.",
    "Kashmir is the northernmost geographical region of the Indian subcontinent. Until the mid-19th century, the term \"Kashmir\" denoted only the Kashmir Valley between the Great Himalayas and the Pir Panjal Range. Today, the term encompasses a larger area that includes the India-administered territories of Jammu and Kashmir and Ladakh, the Pakistan-administered territories of Azad Kashmir and Gilgit-Baltistan, and the Chinese-administered territories of Aksai Chin and the Trans-Karakoram Tract."
    ,"Karachi is the largest city in Pakistan and 12th largest in the world, with a population of over 20 million. It is situated at the southern tip of the country along the Arabian Sea coast. It is the former capital of Pakistan and capital of the province of Sindh. Ranked as a beta-global city, it is Pakistan's premier industrial and financial centre,with an estimated GDP of over $200 billion (PPP) as of 2021.Karachi is Pakistan's most cosmopolitan city, linguistically, ethnically, and religiously diverse cities,as well as one of the most socially liberal.",
    "Multan is a city in Punjab, Pakistan, located on the bank of Chenab River. Multan is one of the five largest urban centres of Pakistan in 2023, with an estimated population of 2.2 million, and is the major cultural, religious and economic centre of Southern Punjab.Multan is known for rich ancient heritage and historic landmarks. The city is one of the oldest and continuously inhabited cities of Asia, with a history stretching deep into antiquity. A historic capital and cultural centre of Punjab and a significant centre of Indus Valley civilization. Multan region was centre of many civilizations throughout its 5 millenia old history."} ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView =findViewById(R.id.recyclerview);
        RecyclerViewAdapters adapters =new RecyclerViewAdapters(cityname,descriptions,price,image,this);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapters);

    }
}