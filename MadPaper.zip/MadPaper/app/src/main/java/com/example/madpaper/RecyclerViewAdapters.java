package com.example.madpaper;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapters extends RecyclerView.Adapter<RecyclerViewAdapters.Viewholder> {

    String textview_name[],textview_Description[],textview_Price[];
    int img[];
    Context ctx;

    public RecyclerViewAdapters(String[] textview_name, String[] textview_Description,String[] textview_Price,int[] img, Context ctx) {
        this.textview_name = textview_name;
        this.textview_Description = textview_Description;
        this.textview_Price = textview_Price;
        this.img = img;
        this.ctx = ctx;
    }

    @NonNull
    @Override
    public RecyclerViewAdapters.Viewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(ctx);
        View view = layoutInflater.inflate(R.layout.item,parent, false);
        Viewholder viewholder = new Viewholder(view);
        return viewholder;
    }



    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapters.Viewholder holder, int position) {
        holder.imageView1.setImageResource(img[position]);
        holder.txtName.setText(textview_name[position]);
        holder.txtDescription.setText(textview_Description[position]);
        holder.txtPrice.setText(textview_Price[position]);

    }

    @Override
    public int getItemCount() {
        return img.length;
    }

    public class Viewholder extends RecyclerView.ViewHolder {
        ImageView imageView1;
        TextView txtName,txtDescription,txtPrice;
        public Viewholder(@NonNull View itemView) {
            super(itemView);
            imageView1 = itemView.findViewById(R.id.imageview);
            txtName = itemView.findViewById(R.id.textviewName);
            txtDescription = itemView.findViewById(R.id.textviewDescription);
            txtPrice = itemView.findViewById(R.id.textviewPrice);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(ctx, Cityinfo.class);
                    intent.putExtra("cityname", textview_name[getAdapterPosition()]);
                    intent.putExtra("citydescription", textview_Description[getAdapterPosition()]);
                    intent.putExtra("cityprice", textview_Price[getAdapterPosition()]);
                    intent.putExtra("image", img[getAdapterPosition()]);
                    ctx.startActivity(intent);
                }
            });
        }


    }
}

